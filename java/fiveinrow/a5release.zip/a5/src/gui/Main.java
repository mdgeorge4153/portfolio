/* NetId(s): djg17, ret87. Time spent: hh hours, mm minutes. */

package gui;

import model.NotImplementedException;

public class Main {
	
	public static void main(String[] args) {
		throw new NotImplementedException();
	}
}
